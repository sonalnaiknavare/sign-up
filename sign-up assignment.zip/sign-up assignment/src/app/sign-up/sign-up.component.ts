import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  public showSignUpWIthLinkedin = true;
  public signUpComplete = false;
  
  clickSignUpWithLinkedin() {
    this.showSignUpWIthLinkedin = false;
    console.log('sign up linkedin clicked');
    var person = { Name: 'John', Email: 'john@email.com'};
    console.log('person details',person)
  }

  registerForm: FormGroup;
    loading = false;
    submitted = false;
    
    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private http: HttpClient
       ) { 
    this.showSignUpWIthLinkedin = true;

        }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            name: ['John Doe', Validators.required],
            email: ['john@requantive.com', [Validators.required]],
            phoneNumber: ['', [Validators.required]],

        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        this.loading = true;
      
    }

    clickOnSignUp(event) {
      //If details are filled,sign up and navigate to home
      console.log('event is', this.registerForm.value);
      if (this.registerForm.value.phoneNumber) {
        this.router.navigate(['home']);
        this.signUpComplete = true;
      } else 
      {
        alert('Please fill the Phone Number!')
      }

    }
}
